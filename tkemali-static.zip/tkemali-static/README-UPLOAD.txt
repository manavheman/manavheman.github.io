Tkemali.de - statische Upload-Version

Inhalt:
- index.html
- impressum/index.html
- datenschutz/index.html
- assets/style.css
- assets/hero-tkemali.webp
- assets/hero-tkemali.png (Reserve)
- assets/favicon.svg
- robots.txt
- sitemap.xml

Upload:
1. Die ZIP entpacken.
2. Den INHALT des Ordners tkemali-static auf den Webspace hochladen.
   Bei vielen Hostern ist das der Ordner public_html oder htdocs.
3. Danach sollte die Startseite unter https://tkemali.de/ erreichbar sein.

Wichtig:
- Vor öffentlicher Nutzung die Platzhalter im Impressum und in der Datenschutzerklärung ersetzen.
- In der Datenschutzerklärung den echten Hosting-Anbieter eintragen.
- Wenn später Analytics, Affiliate-Links, Werbung, Newsletter oder Kontaktformulare dazukommen,
  muss die Datenschutzerklärung angepasst werden.

Empfohlene Weiterleitung:
- tkemali.org -> tkemali.de
- www.tkemali.de -> tkemali.de
